#ifndef ANALYSIS_H_
#define ANALYSIS_H_

int analyze_review(char *fileName, Node *positiveWords, Node *negativeWords);
int count_words(char *reviewString, Node *positiveWords);


#endif